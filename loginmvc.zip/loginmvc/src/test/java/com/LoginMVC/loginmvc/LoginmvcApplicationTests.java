package com.LoginMVC.loginmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
